import java.util.Date;
import java.util.List;

public class User {
    private int id;
    private String name;
    private String email;
    private String password;
    private String role;
    private boolean terms_accepted;
    
    // علاقة المستخدم بالحجوزات
    private List<Reservation> reservations;
}

public class Film {
    private int id;
    private String title;
    private String description;
    private String category;
    private String image;
    private Date release_date;
    private int hours;
    private int min;
    private boolean is_featured;
    
    // علاقة الفيلم بالعروض
    private List<Screening> screenings;
}

public class Salle {
    private int id;
    private String name;
    private int rows_count;
    private int columns_count;
    
    // علاقة القاعة بالمقاعد والعروض
    private List<Seat> seats;
    private List<Screening> screenings;
}

public class Seat {
    private int id;
    private String row_index;
    private int column_index;
    private String type;
    
    // المقعد ينتمي لقاعة
    private Salle salle;
}

public class Screening {
    private int id;
    private Date date;
    private String time;
    
    // العرض يرتبط بفيلم وقاعة ويحتوي على حجوزات
    private Film film;
    private Salle salle;
    private List<Reservation> reservations;
}

public class Snack {
    private int id;
    private String name;
    private String description;
    private float price;
    private String category;
}

public class Reservation {
    private int id;
    private float total_price;
    
    // الحجز يرتبط بمستخدم وعرض، ويشمل مقاعد ووجبات
    private User user;
    private Screening screening;
    private List<Seat> seats;
    private List<Snack> snacks;
}